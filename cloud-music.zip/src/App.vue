<template>
  <div>
    <Header></Header>
    <!-- 路由占位符 -->
    <router-view></router-view>
    <MyFooter></MyFooter>
    <Top></Top>
    <PlayMusic></PlayMusic>
  </div>
</template>

<script>
import Header from '@/components/Header'
import Top from '@/components/top'
import PlayMusic from '@/components/playMusic'
import MyFooter from '@/components/footer/index.vue'
export default {
  name: 'myApp',
  components: {
    Header,
    MyFooter,
    Top,
    PlayMusic
  }
}
</script>

<style lang="less">
*{
  padding: 0px;
  margin: 0px;
  font-size: 12px;
  font-family: Arial, Helvetica, sans-serif;
  -webkit-text-size-adjust: none;
}
body{
  overflow-x: hidden;
}
</style>
