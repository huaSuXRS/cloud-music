import axios from 'axios'

const request = axios.create({
  baseURL: 'http://112.74.179.251:3000'
})

export default request
