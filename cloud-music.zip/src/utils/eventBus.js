import Vue from 'vue'

// 向外共享Vue的实例对象
export default new Vue()
