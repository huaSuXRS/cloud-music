<template>
  <div>
    我的音乐组件
  </div>
</template>

<script>
export default {
  name: 'myMusic'
}
</script>

<style lang="less" scoped>

</style>
