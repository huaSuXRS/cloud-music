<template>
  <div>
    下载客户端组件
  </div>
</template>

<script>
export default {
  name: 'downloadApp'
}
</script>

<style lang="less" scoped>

</style>
