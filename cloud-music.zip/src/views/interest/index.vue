<template>
  <div>

    关注组件
  </div>
</template>

<script>
export default {
  name: 'interestPeople'
}
</script>

<style lang="less" scoped>

</style>
