<template>
  <div class="toplist">
    <div class="toplist_wrap">
      <Left></Left>
      <Right></Right>
    </div>
  </div>
</template>

<script>
import Left from '@/components/findMusic/toplist/left/index.vue'
import Right from '@/components/findMusic/toplist/right/index.vue'
export default {
  name: 'findPlayList',
  components: {
    Left,
    Right
  },
  mounted () {
    document.body.scrollTop = document.documentElement.scrollTop = 0
  }
}
</script>

<style lang="less" scoped>
.toplist{
  width: 100%;
  min-height: 700px;
  background: #f5f5f5;
  .toplist_wrap{
    width: 980px;
    margin: 0 auto;
    border: 1px solid #d3d3d3;
    display: flex;
  }
}
</style>
