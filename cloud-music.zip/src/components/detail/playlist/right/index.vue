<template>
  <div class=""></div>
</template>

<script>
export default {
  name: 'dPlayRight'
}
</script>

<style lang="less" scoped>

</style>
