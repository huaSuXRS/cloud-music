<template>
  <div class=""></div>
</template>

<script>
export default {
  name: 'dPlayLeft'
}
</script>

<style lang="less" scoped>

</style>
