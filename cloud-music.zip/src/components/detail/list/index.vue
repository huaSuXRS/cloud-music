<template>
  <div class=""></div>
</template>

<script>
export default {
  name: 'detailList'
}
</script>

<style lang="less" scoped>

</style>
