module.exports = {
  devServer: {
    // 设置localhost
    host: '127.0.0.1',
    // 设置端口号
    port: '3001',
    // 自动打开浏览器
    open: true
  }
}
